package org.sopt.teatime.c_activities.write.cover.model;

import android.widget.ImageView;
import android.widget.TextView;

public class CoverTemplateViewItem {
    public ImageView imgPicture;
    public TextView txtTitle;
    public TextView txtSubTitle;
    public TextView txtKeyword1;
    public TextView txtKeyword2;
    public TextView txtKeyword3;
    public TextView txtAuthor;
}
