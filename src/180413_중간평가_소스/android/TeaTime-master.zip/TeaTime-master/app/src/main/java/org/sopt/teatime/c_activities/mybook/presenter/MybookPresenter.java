package org.sopt.teatime.c_activities.mybook.presenter;

/**
 * Created by 박은인 on 2016-07-02.
 */
public interface MybookPresenter {
    void getUserList();
}
