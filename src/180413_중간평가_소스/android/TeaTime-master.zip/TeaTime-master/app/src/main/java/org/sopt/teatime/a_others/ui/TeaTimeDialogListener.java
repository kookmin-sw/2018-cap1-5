package org.sopt.teatime.a_others.ui;

public interface TeaTimeDialogListener {

    void clickYes();
    void clickNo();
}
