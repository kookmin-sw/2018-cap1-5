package org.sopt.teatime.c_activities.write.content.model;

import android.widget.ImageView;
import android.widget.TextView;

public class ContentTemplateViewItem {
    public ImageView imgPicture;
    public TextView txtDesc;
}
