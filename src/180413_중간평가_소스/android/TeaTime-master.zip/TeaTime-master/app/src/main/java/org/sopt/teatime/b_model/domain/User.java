package org.sopt.teatime.b_model.domain;

public class User {

    public String profileUrl;
    public String name;
    public String mail;
}
