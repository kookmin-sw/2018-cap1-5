package org.sopt.teatime.c_activities.main.presenter;

/**
 * Created by JH on 2016-06-30.
 */
public interface MainListPresenter {

    void getPhotoCardList();
}
