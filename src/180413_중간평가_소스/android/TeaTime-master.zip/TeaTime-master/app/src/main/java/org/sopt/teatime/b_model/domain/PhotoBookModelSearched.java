package org.sopt.teatime.b_model.domain;

/**
 * Created by 아라 on 2016-07-03.
 */

public class PhotoBookModelSearched {

    public static String profile_url;
    public String title; //포토북 제목
    public String author_nick; // 작성자 아이디
    public String url; //포토북이미지
    public String key1;
    public String key2;
    public String key3;
    public int like_count; //좋아요(하트) 개수
    public int scrap_count; //스크랩 개수
    public int share_count; //공유 개수

}
