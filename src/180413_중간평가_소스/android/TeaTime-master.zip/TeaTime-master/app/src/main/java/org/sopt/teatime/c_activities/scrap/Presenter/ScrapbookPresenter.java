package org.sopt.teatime.c_activities.scrap.Presenter;

/**
 * Created by 박은인 on 2016-07-02.
 */
public interface ScrapbookPresenter {
    void getUserList();
}
