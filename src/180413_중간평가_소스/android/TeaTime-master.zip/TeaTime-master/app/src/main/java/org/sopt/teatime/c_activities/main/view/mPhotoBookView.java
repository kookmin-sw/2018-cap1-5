package org.sopt.teatime.c_activities.main.view;


import org.sopt.teatime.b_model.domain.PhotoBook;

/**
 * Created by JH on 2016-07-07.
 */
public interface mPhotoBookView {
    void setDatas(PhotoBook photoBook);
}
