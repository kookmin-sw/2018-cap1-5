package org.sopt.teatime.c_activities.write.content.view;

import org.sopt.teatime.c_activities.write.content.model.ContentTemplateIds;

public interface DrawContentView {
      void setPreview(ContentTemplateIds ids);
}
