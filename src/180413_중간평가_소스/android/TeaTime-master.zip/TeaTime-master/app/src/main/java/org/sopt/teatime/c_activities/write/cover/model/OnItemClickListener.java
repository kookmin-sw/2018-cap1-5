package org.sopt.teatime.c_activities.write.cover.model;

/**
 * Created by Hyeonu on 2016-07-05.
 */

public interface OnItemClickListener {
    void onItemClick(FontRecyclerItem fontItem);
}
