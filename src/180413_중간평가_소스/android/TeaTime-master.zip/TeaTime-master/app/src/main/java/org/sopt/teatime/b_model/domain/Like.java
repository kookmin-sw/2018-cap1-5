package org.sopt.teatime.b_model.domain;

/**
 * Created by JH on 2016-07-07.
 */
public class Like {

    public int id;

}
