package org.sopt.teatime.c_activities.write.cover.model;

/**
 * Created by 품파파품파 on 2016-07-07.
 */
public class ContentsRecyclerItem {
}
