package org.sopt.teatime.c_activities.contents.presenter;

/**
 * Created by JH on 2016-07-07.
 */
public interface PhotoBookPresenter {

    void getPhotoBookData();
}
