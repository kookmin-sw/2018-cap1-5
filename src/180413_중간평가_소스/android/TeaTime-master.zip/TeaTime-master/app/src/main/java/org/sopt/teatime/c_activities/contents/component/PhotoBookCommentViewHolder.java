package org.sopt.teatime.c_activities.contents.component;

import android.widget.ImageView;
import android.widget.TextView;

/**
 * Created by JH on 2016-07-07.
 */
public class PhotoBookCommentViewHolder {

    ImageView imgProfile;
    TextView txtAuthor;
    TextView txtContents;
}
