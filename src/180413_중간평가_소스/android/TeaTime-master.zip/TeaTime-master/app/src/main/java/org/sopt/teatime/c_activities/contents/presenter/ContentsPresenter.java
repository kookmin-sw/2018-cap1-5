package org.sopt.teatime.c_activities.contents.presenter;

/**
 * Created by JH on 2016-07-02.
 */
public interface ContentsPresenter {

    void getContentsList();
}
