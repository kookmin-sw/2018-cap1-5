package org.sopt.teatime.c_activities.write.cover.model;


/**
 * Created by Hyeonu on 2016-03-22.
 */
public class LayerRecyclerItem {
    int templateCode;

    public LayerRecyclerItem(int templateCode) {
        this.templateCode = templateCode;
    }

    public void setTemplateCode(int templateCode) {
        this.templateCode = templateCode;
    }

    public int getTemplateCode() {
        return templateCode;
    }
}
