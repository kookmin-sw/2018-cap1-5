package org.sopt.teatime.c_activities.write.register.component;

import android.graphics.Typeface;

/**
 * Created by 품파파품파 on 2016-07-08.
 */
public interface PreviewTypeface {
    Typeface getTypeFace(String path);
}
