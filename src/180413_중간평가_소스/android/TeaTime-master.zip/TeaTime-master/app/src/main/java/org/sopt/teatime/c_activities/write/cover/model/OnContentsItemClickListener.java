package org.sopt.teatime.c_activities.write.cover.model;

import org.sopt.teatime.b_model.domain.PhotoBook;

/**
 * Created by Hyeonu on 2016-07-05.
 */

public interface OnContentsItemClickListener {
    void onItemClick(PhotoBook photoBook);
}
