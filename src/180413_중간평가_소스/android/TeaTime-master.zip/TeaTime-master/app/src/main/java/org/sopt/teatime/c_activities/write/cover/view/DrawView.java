package org.sopt.teatime.c_activities.write.cover.view;

import org.sopt.teatime.c_activities.write.cover.model.CoverTemplateId;

public interface DrawView {
      void setPreview(CoverTemplateId ids);
}
