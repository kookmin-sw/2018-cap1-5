package org.sopt.teatime.c_activities.search.component;

import android.widget.ImageView;
import android.widget.TextView;

/**
 * Created by 아라 on 2016-07-03.
 */
public class PhotoBookListViewHolder {
    public ImageView imgProfile;
    public TextView title;
    public TextView subTitle;
}
